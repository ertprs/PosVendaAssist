<?php
include '/var/www/assist/www/dbconfig.php';
include '/var/www/includes/dbconnect-inc.php';
include 'mlg_funciones.php';

//	AJAX
if ($_GET['action']=='cidades') {
	$estado = $_GET['estado'];
	if ($estado == "") {echo "Erro na consulta!"; exit;}
	$fabrica = "2";
	if(strlen($estado) > 0) {   // SELECIONA AS CIDADES
		$sql_cidades =	"SELECT  LOWER(mlg_cidade) AS cidade
							FROM (SELECT posto,tipo_posto,UPPER(TRIM(TRANSLATE(contato_cidade,'������������������������������������������',
																							  'aaaaaeeeeiiiioooouuucAAAAAEEEEIIIIOOOOUUUC')))
														AS mlg_cidade,
										contato_estado	AS mlg_estado
							FROM tbl_posto_fabrica
								WHERE credenciamento='CREDENCIADO'
									AND tbl_posto_fabrica.posto NOT IN(6359,20462)
									AND tbl_posto_fabrica.credenciamento = 'CREDENCIADO'
									AND tbl_posto_fabrica.tipo_posto <> 163
									AND contato_estado='$estado' AND fabrica=$fabrica) mlg_posto
							GROUP BY mlg_posto.mlg_cidade ORDER BY cidade ASC";
		$res_cidades = pg_query($con,$sql_cidades);
		$tot_i       = pg_num_rows($res_cidades);
        echo "<OPTION></OPTION>";
        for ($i; $i<$tot_i; $i++) {
            list($cidade_i,$cidade_c) = split("#",htmlentities(pg_fetch_result($res_cidades, $i, cidade)));
            $sel      = ($tot_i == 1)?" SELECTED":"";
			echo "\t\t\t<OPTION value='$cidade_i'$sel>".ucwords($cidade_i." ".$cidade_c)."</OPTION>\n";
        }
        if ($tot_i==0) echo "<OPTION SELECTED>Sem resultados</OPTION>";
	}
	exit;
}

if ($_GET['action']=='postos') {    // SELECIONA OS POSTOS CREDENCIADOS DA CIDADE $cidade
	$estado = $_GET['estado'];
	if (isset($_GET['cidade'])) $cidade=strtoupper(utf8_decode($_GET['cidade']));
	if ($estado == "" or $cidade=="") {echo "Erro na consulta!"; exit;}
	$fabrica = "2";
	$sql = "SELECT
				tbl_posto.posto,
				tbl_posto_fabrica.codigo_posto,
				TRIM(tbl_posto_fabrica.contato_endereco)	AS endereco,
				tbl_posto_fabrica.contato_numero			AS numero,
                TRIM(tbl_posto.nome)						AS nome,
				LOWER(TRIM(TRANSLATE(tbl_posto_fabrica.contato_cidade,'���������������������',
																	  '���������������������')))
															AS cidade,
				tbl_posto_fabrica.contato_estado			AS estado,
				tbl_posto_fabrica.contato_bairro			AS bairro,
				tbl_posto_fabrica.contato_cep				AS cep,
				tbl_posto_fabrica.nome_fantasia,
                tbl_posto.latitude,
                tbl_posto.longitude,
                TRIM(tbl_posto_fabrica.contato_email)		AS email,
				tbl_posto_fabrica.contato_fone_comercial	AS fone
			FROM   tbl_posto
			JOIN    tbl_posto_fabrica USING (posto)
			JOIN    tbl_fabrica       USING (fabrica)
			WHERE   tbl_posto_fabrica.fabrica = $fabrica
			AND tbl_posto_fabrica.contato_estado ILIKE '$estado'
			AND UPPER(TRIM(TRANSLATE(contato_cidade,'������������������������������������������',
													'aaaaaeeeeiiiioooouuucAAAAAEEEEIIIIOOOOUUUC')))
						ILIKE '%".tira_acentos($cidade)."%'
			AND tbl_posto.posto not in(6359,20462)
			AND tbl_posto_fabrica.credenciamento = 'CREDENCIADO'
			AND tbl_posto_fabrica.tipo_posto <> 163
			AND tbl_posto_fabrica.atende_consumidor IS TRUE
			ORDER BY tbl_posto_fabrica.contato_bairro, tbl_posto.nome";
		$res = pg_query ($con,$sql);
		$total_postos = ($tem_mapa=pg_num_rows($res));
		$cidade = pg_fetch_result($res, $total_postos-1, cidade);
		
		echo "<table align='center' id='postos'>\n";
		echo "\t<caption>Rela&ccedil;&atilde;o de Postos ";
		echo ($cidade<>"")?"da cidade de <span class='nome_cidade'>".change_case($cidade,'l')."</span>, ":"";
		foreach ($estados_BR_prefixo as $pre => $pre_estado) {
			if (array_search($estado, $pre_estado) <> false) {echo $pre; break;}
		}
		echo " ".$estados[$estado];
		echo "\t</caption>";

		if($total_postos > 0){?>
        <thead>
            <tr align='center' class='bold'>
                <th width='266'>Nome do Posto</th>
                <th width='298'>Endere&ccedil;o</th>
                <th width='150'>E-Mail</th>
                <th width= '98'>Telefone</th>
                <th width= '32'>Mapa</th>
                <th width='174'>Linhas</th>
            </tr>
        </thead>
<?
			for ($i = 0 ; $i < $total_postos ; $i++) {
                $row = pg_fetch_array($res, $i);
                foreach ($row as $campo => $valor) {
                    $$campo = trim($valor);
                }
				$end_completo = $endereco . ", " . $numero  . " - " . $bairro;
				$end_mapa     = "$endereco, $numero, $cep, $cidade, $estado, Brasil";
 				if (is_numeric($longitude) and is_numeric($latitude)) { // lat e long est�o ao contr�rio no banco
 				    $end_mapa.= "&ll=$longitude,$latitude";
				}
// 					$link_mapa = "<a title='Localizar no mapa' href='http://maps.google.com/maps?f=q&source=s_q&hl=pt-BR&geocode=&q=$longitude,$latitude&sll=$end_mapa&ie=windows-1252' target='_blank'>";
// 				}else {
					$link_mapa = "<a title='Localizar no mapa' href='http://maps.google.com/maps?f=q&source=s_q&hl=pt-BR&q=$end_mapa&ie=windows-1252' target='_blank'>";
//  				}
				$link_mapa.= "<img src='http://www.impressionar.com.br/multimidia/_arquivos/mapa.jpg' width='16'></a>";

				echo "\t\t<tr>";
				$posto_nome = iif((strlen($nome_fantasia)>0),$nome_fantasia,$nome);
				$tooltip .= " title='".iif(($posto_nome==$nome_fantasia),"$posto_nome ($nome)",
										iif((strlen($posto_nome)>=40),"$posto_nome",""))."'";
				echo "\t\t\t<td$tooltip>$posto_nome</td>";
				$tooltip = (strlen($end_completo)>=44)?" title='$end_completo'":"";
				echo "\t\t\t<td$tooltip>$end_completo</td>";
				$tooltip = (strlen($email)>=30)?" title='$email'":"";
				echo "\t\t\t<td$tooltip>";
                if (strlen($email)>5 and strpos($email,"@",1)>0) {
                	echo "<a href='mailto:".strtolower($email)."'>$email</a>";
                } else {
					echo "<i>sem e-mail</i></td>";
				}
				echo "\t\t\t<td><a href='callto:$fone'>$fone</a></td>";
				echo "\t\t\t<td>$link_mapa</td>";
//  Linhas que o Posto Autorizado atende...
					$sql_linhas = "SELECT tbl_linha.nome FROM tbl_posto_linha
											JOIN tbl_linha USING(linha)
										WHERE tbl_posto_linha.ativo IS NOT FALSE
											  AND posto = $posto AND fabrica=$fabrica";
					$res2 = pg_query ($con,$sql_linhas);
					if(pg_numrows($res2) > 0){
// 						$linhas = "<DIV>Esta assist�ncia atende...<br>";
						$linhas = "<SELECT readonly><option>Esta assist�ncia atende...</option>";
						for ($x = 0 ; $x < pg_numrows ($res2) ; $x++) {
// 							$linhas .= "... ".trim(pg_fetch_result($res2,$x,nome))."<br>\n";
							$linhas .= "<option>... ".trim(pg_fetch_result($res2,$x,nome))."</option>\n";
						}
// 						$linhas.= "</DIV>\n";
					}
				echo "\t\t\t<td>$linhas</td>";
				echo "\t\t</tr>";
				unset ($end_mapa, $link_mapa, $tooltip, $end_completo, $posto_nome, $linhas);
			}
		}else{
			echo "\t<tr><td class='fontenormal'> Nenhuma Assist�ncia T�cnica encontrada.</td></tr>";
		}
		echo "</table>\n<br>";
	exit;
}
//  FIM AJAX

$html_titulo = "Dynacom - Mapa da Rede Autorizada";
include "cabecalho.php";
?>
<!-- CSS -->
<style type="text/css">
<!--
body {
	line-height: 1.2em;
	color:#88A;
	top: 0;
	left: 0;
	padding: 30px 10px 15px 10px;
}

* {
	font-family: sans-serif, Verdana, Geneva, Arial, Helvetica;
	font-size: 11px;
}
#sel_cidade, #tblres {display: none;}
#sel_cidade {position: relative; top: 2em;}

h2 {
	padding-left: 1em;
	font: normal bold 15px helvetica,Arial,sans-serif;
	color: #333;
	text-align: left;
    text-transform: uppercase;
}
#mapabr {position:relative;float: left;top: -1em;height:340px}
	#mapabr span {
		padding: 2px 4px;
		color: white;
		background-color: #A10F15;
	    text-shadow: 0 0 0 transparent;
		font: inherit
}
#mapabr h2 {margin-top: 1.5em}

area {cursor: pointer}
a img {border: 0 solid transparent;}
#frmdiv {
	float: left;
	margin: 1em;
	text-align: left;
	width: 512px;
}

label, select {margin-left: 2em;z-index:10}

fieldset {
	border-radius: 5px;
	-moz-border-radius: 5px;
	-webkit-border-radius: 5px;
	height: 365px;
	width: 500px;
}

#mensagem_dynacom {
	position: relative;
	top: -1.5em;
	float: left;
	line-height: auto;
	width:40%;
	}
	#mensagem_dynacom h4, #mensagem_dynacom h5 {
		color: red;
		font-size: 20px;
		line-height: 22px;
		margin: 1.5em 20px 20px 0.5em;
		text-align: center;
	}
	#mensagem_dynacom p {
	    color: black;
		font-size: 15px;
		line-height: 17px;
	    margin: 1em 15px 0 15px;
	    text-align: justify;
	}
	#mensagem_dynacom p b {font: inherit; font-weight: bold}
	#mensagem_dynacom h4:first-line {
		color: black;
	}
	#mensagem_dynacom div {
		text-align: center;
}

#tblres {
	position: relative;
	clear: both;
}
#tblres table {
	position: relative;
	table-layout: fixed;
	margin: 0;
    background-color: transparent;
	padding: 0;
	width: 700px;
	overflow-x: hidden;
}
#tblres table td {
    position: relative;
	background: #ddd;
/*	font-weight: bold;*/
	padding: 4px 2px;
	border:	1px solid #666;
	border-right:  1px solid #eee;
	border-bottom: 1px solid #eee;
    color: black;
	white-space: nowrap;
	overflow: hidden;
	text-transform: uppercase;
	cursor: default;
}

#tblres td a {padding-left: 1ex;text-decoration: none;color:#114}
#tblres td a:hover {border-bottom: 1px dashed #667}

#tblres table td:nth-child(3) {text-transform: lowercase}
#tblres table td:nth-child(4) {text-align: right}
#tblres table td:nth-child(5) {text-align: center}
#tblres table td:nth-child(6) {text-align: left}
#tblres table td:nth-child(6):hover {overflow: visible}

#tblres table td div {
	position:relative;
	z-index:5;
	width: 165px;
	height:1.1em;
	overflow: hidden;
	}
#tblres table td div p {
	position: absolute;
	top: 1px; left: 2px;
	}
	#tblres table td div:hover {
	    background-color: white;
	    height: auto;
	    border: 1px dashed #335;
		overflow: visible;
}

td select {
	border: 0;
}

#tblres table caption {
	font: normal bold 1.2em "Trebuchet MS",Helvetica,Arial,sans-serif;
	padding-bottom: 4px;
	border-bottom: 1px solid white;
	text-align: center;
}
#tblres td  select {margin-left: 2px;text-transform:capitalize;}

.nome_cidade {text-transform:capitalize;text-decoration:underline; font: inherit}

.cinza {#667}
.bold {
	font-weight: bold;
}
//-->
</style>

<!-- JavaScript -->
<!--[if lt IE 8]>
	<script src="http://ie7-js.googlecode.com/svn/version/2.0(beta3)/IE8.js" type="text/javascript"></script>
<![endif]-->
<script src="jquery-1.3.2.min.js" type="text/javascript"></script>

<script type="text/javascript">
$(document).ready(function() {
//  Adiciona um evento onClick para cada 'area' que vai alterar o valor do SELECT 'estado'
	$('map area').click(function() {
		$('#estado').val($(this).attr('name'));
		$('#estado').change();
	});
	$('#sel_cidade').hide('fast');

//  Quando muda o valor do select 'estado' requisita as cidades onde tem postos autorizados e os
//  insere no select 'cidades'
	$('#estado').change(function() {
	    var estado = $('#estado').val();
	    if (estado == '') {
			$('#sel_cidade').hide(500);
			$('#tblres').html('').fadeOut(400);
			return false;
		}
		$.get("<?=$PHP_SELF?>", {'action': 'cidades','estado': estado},
		  function(data){
			if (data.indexOf('Sem resultados') < 0) {
				$('#sel_cidade').show(500);
			    $('#cidades').html(data).val('').removeAttr('disabled');
				if ($('#cidades option').length == 2) {
	                $('#cidades option:last').attr('selected','selected');
	                $('#cidades').change();
				}
			} else {
			    $('#cidades').html(data).val('Sem resultados').attr('disabled','disabled');
			}
			$('#tblres').html('').fadeOut(400);
		  });
	});

	$('#cidades').change(function() {
		$('#tblres').fadeOut('fast');
	    var estado = $('#estado').val();
		var cidade = $('#cidades').val();
		$.get("<?=$PHP_SELF?>", {'action': 'postos','estado': estado,'cidade': cidade},
		  function(data){
		    if (data.indexOf('Nenhuma') < 0) {
				$('#tblres').html(data).fadeIn(500);
			}
		  });
	});
}); // FIM do jQuery
</script>
<script language="javascript">AC_FL_RunContent = 0;</script>
<script src="../js/AC_RunActiveContent2.js" language="javascript"></script>

<base href="http://www.telecontrol.com.br/mapa_rede/img_dynacom/">
</head>

<body background="../../imagens/plano.png" bgcolor="#000000" topmargin="0" leftmargin="0">
<center>
<table border="0" cellpadding="0" cellspacing="0" width="1000">
    <tr>
        <td align="center"><font color="#000000"><script language="javascript">
	if (AC_FL_RunContent == 0) {
		alert("This page requires AC_RunActiveContent.js.");
	} else {
		AC_FL_RunContent(
			'codebase', 'http://download.macromedia.com/pub/shockwave/cabs/flash/swflash.cab#version=9,0,0,0',
			'width', '1000',
			'height', '123',
			'src', '../../js/menucima1',
			'quality', 'best',
			'pluginspage', 'http://www.macromedia.com/go/getflashplayer',
			'align', 'middle',
			'play', 'true',
			'loop', 'true',
			'scale', 'showall',
			'wmode', 'transparent',
			'devicefont', 'false',
			'id', 'menucima1',
			'bgcolor', '#000000',
			'name', 'menucima1',
			'menu', 'false',
			'allowFullScreen', 'false',
			'allowScriptAccess','sameDomain',
			'movie', '../../js/menucima1',
			'salign', ''
			); //end AC code
	}
</script>
<noscript>
	<object classid="clsid:d27cdb6e-ae6d-11cf-96b8-444553540000" codebase="http://download.macromedia.com/pub/shockwave/cabs/flash/swflash.cab#version=9,0,0,0" width="1000" height="123" id="menucima1" align="middle">
	<param name="allowScriptAccess" value="sameDomain" />
	<param name="allowFullScreen" value="false" />
	<param name="movie" value="../js/menucima1.swf" /><param name="menu" value="false" /><param name="quality" value="best" /><param name="wmode" value="transparent" /><param name="bgcolor" value="#000000" />	<embed src="../js/menucima1.swf" menu="false" quality="best" wmode="transparent" bgcolor="#000000" width="1000" height="123" name="menucima1" align="middle" allowScriptAccess="sameDomain" allowFullScreen="false" type="application/x-shockwave-flash" pluginspage="http://www.macromedia.com/go/getflashplayer" />
	</object>
</noscript></font></td>
    </tr>
</table>
<p>A meta de nossa empresa � fornecer produtos com um excelente padr�o de qualidade e garantia, ligados com a tecnologia do presente, de caracter�sticas funcionais. Para isso contamos tamb�m com uma equipe de assist�ncia t�cnica em todo o Brasil treinada para melhor atend�-lo.
</p>
	<div id='frmdiv'>
		<form name='frm_mapa_rede_gama' action='<?=$PHP_SELF?>' method='post'>
			<fieldset for="frm_mapa_rede_gama">
				<legend>Pesquisa de Postos Autorizados</legend>
				<div id='mapabr'>
					<h2>Assist�ncia T�cnica</h2>
					<map name="Map2">
						<area shape="poly" name="RS" coords="122,238,142,221,164,232,148,262">
						<area shape="poly" name="SC" coords="143,214,172,215,169,235,143,219">
						<area shape="poly" name="PR" coords="138,202,148,191,166,192,175,207,171,214,139,213">
						<area shape="poly" name="SP" coords="152,187,162,173,182,174,186,187,188,194,197,190,197,198,177,206,168,190">

						<area shape="poly" name="MS" coords="136,195,156,171,138,159,124,159,117,182">
						<area shape="poly" name="MT" coords="117,151,143,151,160,127,160,106,120,105,111,101,98,102,107,117,100,131,102,142">
						<area shape="poly" name="RO" coords="93,126,98,118,94,113,86,105,86,100,80,93,73,102,67,108,67,116,77,121">
						<area shape="poly" name="AC" coords="50,106,10,91,13,101,23,104,29,104,30,112,44,113">
						<area shape="poly" name="AM" coords="11,87,53,101,74,88,105,91,117,55,103,43,89,50,76,43,77,30,62,37,43,30,40,38,33,75,21,75,13,82">
						<area shape="poly" name="RR" coords="74,13,74,18,82,25,84,41,93,40,102,31,96,21,97,9,90,11">
						<area shape="poly" name="PA" coords="112,33,114,40,127,50,117,82,121,95,162,99,174,77,173,68,193,48,172,54,158,55,145,45,133,25">
						<area shape="poly" name="AP" coords="145,25,153,23,157,13,164,29,153,41">
						<area shape="poly" name="MA" coords="196,50,185,72,194,90,212,82,215,59">

						<area shape="poly" name="TO" coords="179,83,165,120,189,128,185,101">
						<area shape="poly" name="GO" coords="159,166,148,157,165,131,188,136,170,151">
						<area shape="poly" name="PI" coords="201,92,216,86,223,64,228,85,219,98,207,99,206,107,199,107">
						<area shape="poly" name="RJ" coords="206,201,202,190,214,189,218,181,226,187">
						<area shape="poly" name="MG" coords="171,164,190,162,192,145,205,140,217,146,224,154,217,169,212,183,193,183,185,170">
						<area shape="poly" name="ES" coords="236,167,228,162,221,177,226,183">
						<area shape="poly" name="BA" coords="198,113,196,134,213,133,230,139,235,146,231,157,235,160,240,142,241,127,249,124,243,113,243,105,234,106,225,107,215,107,207,115">
						<area shape="poly" name="CE" coords="230,59,235,86,241,86,252,70,239,61">
						<area shape="poly" name="SE" coords="250,108,248,113,251,118,257,113,252,109">

						<area shape="poly" name="AL" coords="266,102,258,104,251,102,260,110,266,104">
						<area shape="poly" name="PE" coords="269,94,269,99,262,99,256,101,251,98,246,98,239,96,234,100,231,95,234,92,243,93,251,94,255,96">
						<area shape="poly" name="PB" coords="269,85,262,85,257,88,253,85,248,87,257,90,263,91,268,89">
						<area shape="poly" name="RN" coords="256,73,249,81,256,80,257,83,270,82,265,76">
						<area shape="poly" name="DF" coords="168,162,171,153,183,149,182,161">
					</map>
					<p style='textalign: right; font-weight: bold;'>Selecione o Estado:</p>
					<img src="dynacom_mapa.gif" usemap="#Map2" border="0">
				</div>
				<label for='estado'>Selecione o Estado</label><br>
				<select title='Selecione o Estado' name='estado' id='estado'>
					<option></option>
<?				foreach ($estados as $sigla=>$nome) {
					echo "\t\t\t\t<option value='$sigla'>$nome</option>\n";
				}
?>				</select>
				<div id='sel_cidade'>
		            <label for='cidades'>Selecione uma cidade</label><br>
					<select title='Selecione uma cidade' name='cidades' id='cidades'>
						<option></option>
					</select>
				</div>
			</fieldset>
		</form>
	</div>
	<div id='mensagem_dynacom'>
	    <h5>Voc&ecirc; sabia que 80% dos casos de mau funcionamento do seu Dynacom podem ser
	        resolvidos sem a Assist&ecirc;ncia T&eacute;cnica?</h5>
		<p>Consulte o <b>manual simplificado</b> de seu aparelho ou as dicas de conserto do
	       <b>Manual do Usu&aacute;rio</b>, tamb&eacute;m dispon&iacute;veis na &aacute;rea de
		   downloads de nosso site, e esclare&ccedil;a voc&ecirc; mesmo.</p>
		<p>Caso seu problema n&atilde;o tenha sido solucionado, ligue para nosso <b>Servi&ccedil;o
		   de Atendimento ao Consumidor</b>:</p>
		   <h4>Capital e Grande S&atilde;o Paulo<br>
		   (11) 3366-9166</h4>
		   <h4>Demais localidades do Brasil<br>
		   (11) 0800-770 1699</h4>
		<div>Hor&aacute;rio de atendimento: de Segunda a Sexta, das 09:00 &agrave;s 16:00h.</div>
	</div>
	<p>&nbsp;</p>
	<div id='gmapsd'></div>
	<div id='tblres'>&nbsp;</div>
<table border="0" cellpadding="0" cellspacing="0" width="1000">
    <tr>
        <td align="center"><font color="#FFFFFF"><script language="javascript">
	if (AC_FL_RunContent == 0) {
		alert("This page requires AC_RunActiveContent.js.");
	} else {
		AC_FL_RunContent(
			'codebase', 'http://download.macromedia.com/pub/shockwave/cabs/flash/swflash.cab#version=9,0,0,0',
			'width', '1000',
			'height', '44',
			'src', '../../js/menucima3',
			'quality', 'best',
			'pluginspage', 'http://www.macromedia.com/go/getflashplayer',
			'align', 'middle',
			'play', 'true',
			'loop', 'true',
			'scale', 'showall',
			'wmode', 'transparent',
			'devicefont', 'false',
			'id', 'menucima3',
			'bgcolor', '#FFFFFF',
			'name', 'menucima3',
			'menu', 'true',
			'allowFullScreen', 'false',
			'allowScriptAccess','sameDomain',
			'movie', '../../js/menucima3',
			'salign', ''
			); //end AC code
	}
</script>
<noscript>
	<object classid="clsid:d27cdb6e-ae6d-11cf-96b8-444553540000" codebase="http://download.macromedia.com/pub/shockwave/cabs/flash/swflash.cab#version=9,0,0,0" width="1000" height="44" id="menucima3" align="middle">
	<param name="allowScriptAccess" value="sameDomain" />
	<param name="allowFullScreen" value="false" />
	<param name="movie" value="../../js/menucima3.swf" /><param name="quality" value="best" /><param name="wmode" value="transparent" /><param name="bgcolor" value="#FFFFFF" />	<embed src="../../js/menucima3.swf" quality="best" wmode="transparent" bgcolor="#FFFFFF" width="1000" height="44" name="menucima3" align="middle" allowScriptAccess="sameDomain" allowFullScreen="false" type="application/x-shockwave-flash" pluginspage="http://www.macromedia.com/go/getflashplayer" />
	</object>
</noscript></font></td>
    </tr>
</table>
<table border="0" cellpadding="0" cellspacing="0"  width="1000" height="30">
    <tr align="center"><td width="300" background="imagens/fd2.png"><font color="#FFFFFF"></font></td>
        <td width="100" bgcolor="#FFFFFF" ><font color="#FFFFFF">.........</font></td>
        <td width="300" background="imagens/fd2.png"><font color="#FFFFFF"></font></td>
        <td align="right" width="300" bgcolor="#FFFFFF" ><font color="#FFFFFF"><FONT style="FONT-SIZE: 10px; FONT-FAMILY: arial,tahoma,verdana,helvetica" color="#c0c0c0">

Copyright � Marca Dynacom - 2009<br>
E-mail: mkt@dynacom.com.br<br>
Site melhor visualizado em resolu��o de 1024 x 768 pixels

<br>

</font>
</font></td>
    </tr>
</table>
</body>
</html>